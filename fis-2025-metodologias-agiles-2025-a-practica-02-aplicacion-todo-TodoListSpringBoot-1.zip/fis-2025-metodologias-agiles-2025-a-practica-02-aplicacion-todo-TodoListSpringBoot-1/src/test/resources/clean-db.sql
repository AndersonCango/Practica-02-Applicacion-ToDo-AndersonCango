DELETE FROM tareas;
DELETE FROM usuarios;
